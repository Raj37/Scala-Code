

class TakeOrder {
  def takingOrder(n:Int)={
		for(i<-1 to n){
			println("ENTER SIZE OF "+i+" PIZZA\n"+"LARGE OR MEDIUM OR SMALL")
			var size=scala.io.StdIn.readLine().toUpperCase().concat(" ")
			strBuilder.append(size)


		}
		strBuilder.append("|")
		println("ORDERED PIZZA SIZE: "+strBuilder)
}
}
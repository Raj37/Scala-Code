

object Order extends App {
	//val strBuilder = StringBuilder.newBuilder
val tkorder=new TakeOrder()
			println("KINDLY ENTER NO'S OF PIZZA YOU WANT TO ORDER..")
			var n=scala.io.StdIn.readInt()
			if(n>0){
				tkorder.takingOrder(n)
			}
			else{
				println("KINDLY ORDER SOMETHING OTHER WISE GET LOST..!!")
			}
	}


//println("ORDERED PIZZA SIZE: "+strBuilder)
}


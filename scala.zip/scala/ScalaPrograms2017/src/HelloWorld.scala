import scala.collection.immutable.StringLike

object HelloWorld {
  def main(args: Array[String]) {
    println("Inside main method of scala program..")
    var count: Int = 1
    var age: Int = 30

    val name: String = "Raj Kamal"

    println(count + ". Age=> " + age + " and Name=> " + name)
    count += 1
    val name2 = "Subu"

    age = 31

    println(count + ". Age=> " + age + " and Name=> " + name2)

    var a: Any = "9900sae"

    var b: AnyVal = 500

    var c: AnyRef = "100"

    println("a=> " + a + " b=>" + b + " c=>" + c)

    if (name.endsWith("Kamal")) {
      fun("10".toInt)
    }
    def fun(a: Int) = {
      println("Inside fun() method with method argument=> " + a)
    }

    //scala concatenate operations

    println("scala concatenation operations=>" + ("scala".drop(3).take(4)))

    //Multiline string support in scala

    var tableName = args(0)
    var ageLimit = args(1)
    var sqlLimit = args(2)

    var sqlString: String = s"""SELECT name,age,salary
		FROM $tableName
		WHERE age>$ageLimit
		LIMIT $sqlLimit"""

    println(s"$sqlString")

    //Example of Type Inferred
    var i = 100
    println("Above statement automatically identified data type of i i.e. Int")

    //Multiple assignments
    val (dept, id, loc) = ("Hadoop", 500, "Pune")
    println("Dept=>" + dept + " Id=>" + id + " Location=>" + loc)
    
    val (name1,age1,city)=("Raj",27,"Pune")
    println("Name=>"+name1+" Age=>"+age1+" City=>"+city)
    
    val c1=new Connection
    c1.makeConnection()
    c1.makeConnection(2000)
    c1.makeConnection(3000,"https")
    c1.makeConnection(timeout=1000,protocol="https")
    c1.makeConnection(protocol="https",timeout=7000)
  }

}
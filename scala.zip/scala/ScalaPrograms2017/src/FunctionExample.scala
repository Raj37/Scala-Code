

object FunctionExample extends App {

  def fun(a: Int): Int = {
    a + 1
    a - 2
    a * 3
  }
  val p: Int = fun(10)
  println("p=>" + p)

  val f = (x: Int) => { x + 1; x - 2; x * 3 }
  println("f()=>" + f(10))

  def add(a: Int, b: Int) = {
    a + b

  }
  val m = add(1, 2)
  println("m=>" + m)

  //Returning multiple items from a method
  def getStockInfo = {
    ("NFLX", 100.00, 101.00)
  }
  //First Way
  val (symbol, currentPrice, bidPrice) = getStockInfo

  println("symbol=>" + symbol)
  println("currentPrice=>" + currentPrice)
  println("bidPrice=>" + bidPrice)
  //Second Way
  val x = getStockInfo

  println("symbol=>" + x._1)
  println("currentPrice=>" + x._2)
  println("bidPrice=>" + x._3)
}

object VarArgs {
	def main(args:Array[String]){
		def printAll(strings:String*){
			strings.foreach(println)
		}

		printAll()
		printAll("foo")
		printAll("foo","bar")
		printAll("foo","bar","baz")
	}
}
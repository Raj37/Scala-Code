
import java.util.Scanner
object Swapping extends App {

	val scanner = new java.util.Scanner(System.in)
			print("Enter value of a \n")
			var a = scanner.nextLine()
			var a1 = a.toInt
			//print("a=>" + a1)

			print("Enter value of b \n")
			var b = scanner.nextLine()
			var b1 = b.toInt
			//print("b=>" + b1)
			print("Before swapping a=>"+a1+"b=>"+b1)
			a1 = a1 + b1
			b1 = a1 - b1
			a1 = a1 - b1

			println("\nAfter swapping a=>" + a1 + " b=>" + b1)

}


object Tuple extends App{

	val things = ("Raj",100,"Pune","Bigdata")

			println(things._1)//First item in tuple

			println(things._2)//Second item in tuple

			println(things._3)//Third item in tuple

			println(things._4)//Fourth item in tuple

			def getUserInfo=("Kamal","Pune","Spark")

			val(lname,city,tech) = getUserInfo

			println("\nLastName=>"+lname+" City=>"+city+" Technology=>"+tech)

}


class Connection {
  def makeConnection(timeout:Int=5000,protocol:String="http"){
    println(s"timeout=>$timeout"+"\t"+s"protocol=>$protocol")
  }
}

//val c=new Connection

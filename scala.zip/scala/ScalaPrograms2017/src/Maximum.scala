
import java.util.Scanner
object Maximum extends App {

	//passing values of a, b and c by arguments setting
	var a = args(0)
			var b = args(1)
			var c = args(2)

			if (a > b && b > c) {
				println("a is biggest one..!!")
			} else if (b > a && a > c) {
				println("b is biggest one..!!")
			} else
				println("c is biggest one..!!")

				//Prompt user for values of a, b and c
				val scanner = new java.util.Scanner(System.in)
				print("Enter value of a \n")
				val a1 = scanner.nextLine()
				print("value of a is :" + a1)

				print("Enter value of b \n")
				val b1 = scanner.nextLine()
				print("value of b is :" + b1)

				print("Enter value of c \n")
				val c1 = scanner.nextLine()
				print("value of c is :" + c1)

				if (a1 > b1 && b1 > c1) {
					println("\na is biggest one..!!")
				} else if (b1 > a1 && a1 > c1) {
					println("\nb is biggest one..!!")
				} else
					println("\nc is biggest one..!!")

}
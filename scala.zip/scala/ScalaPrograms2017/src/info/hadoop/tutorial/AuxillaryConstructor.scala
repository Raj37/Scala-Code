package info.hadoop.tutorial


object AuxillaryConstructor {
  def main(args: Array[String]) {
    val subu = new Employee1()
    println("Subu records=>" + subu.name + " " + subu.age + " " + subu.salary + " " + subu.address)
    val raj = new Employee1("raj")
    println("Subu records=>" + raj.name + " " + raj.age + " " + raj.salary + " " + raj.address)
  
  }

}

class Employee1(val name: String, var age: Int, val salary: Float, var address: String) {

  def this() {
    this(" ", 0, 0.0f, " ") //can set default values of class parameters
  }

  def this(name: String) {
    this("name", 0, 0.0f, " ")
  }
}
package info.hadoop.tutorial

object CaseClass {
  def main(args:Array[String]){
//    val p = Array(Person2("Raj Kamal"),Person2("Siva"))
    val p=Person2("Raj Kamal")
    p.printMsg()
    
  }
}

case class Person2(var name:String){
  var age:Int=40
  var location:String="Pune"
  def printMsg()={
    println(s"Msg details=>$name,$age,$location")
  }
//  val siva = new Person2("Siva")
}
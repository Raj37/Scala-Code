package info.hadoop.tutorial

object DiamondProblem {
  def main(args:Array[String]){
    println((new A).op)
    println((new B).op)
    println((new C).op)
  }
}

trait Base{
  
  def op:String
  
  def printMsg()=println("method inside trait")
  }

trait foo extends Base{override def op="foo"}

trait bar extends Base{override def op="bar"}

trait beer extends Base{override def op="beer"}

class A extends foo with bar

class B extends bar with beer

class C extends bar with foo with beer


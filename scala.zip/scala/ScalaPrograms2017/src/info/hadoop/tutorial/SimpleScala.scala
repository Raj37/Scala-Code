package info.hadoop.tutorial

object SimpleScala {
	def main(args:Array[String]){
		//println("Simple Scala Program")
		val raj = new Employee("Raj Kamal",26,5555.55f,"Pune")
				//println("Raj Records=>"+raj.name+" "+raj.age+" "+raj.salary+" "+raj.address)
				//raj.name="Subu"
				//raj.salary=6000.50f
				//raj.salary_$eq(7500.50f)
				//raj.deriveDeptName("Bigdata")
				//println("Raj New Records=>"+raj.name+" "+raj.age+" "+raj.salary+" "+raj.address)
	}
}

class Employee(var name:String,var age:Int,var salary:Float,var address:String){
	println("Entered into class")
	println(deriveDeptName("bigdata"))
	def deriveDeptName(name:String)=name.toUpperCase()
	println("Exited from class")
}
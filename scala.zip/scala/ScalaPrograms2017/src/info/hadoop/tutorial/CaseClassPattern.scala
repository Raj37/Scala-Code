package info.hadoop.tutorial

object CaseClassPattern {
  def main(agrs: Array[String]) {
        var a = Person3("Siva")
        a.fun(a)
    //    var b = Person3("Raj")
    //    b.fun(b)
    //    var c = Person3("Kamal")
    //    c.fun(c)
  }
}

case class Person3(var name: String) {
  //var a = Person3("Siva")
  def fun(p: Person3) = p match {
    case Person3("Siva") => println("Siva")

    case Person3("Raj")  => println("Raj")

    case _               => println("Default")
  }
//  val f = fun(a)
//  println(fun(a))
}
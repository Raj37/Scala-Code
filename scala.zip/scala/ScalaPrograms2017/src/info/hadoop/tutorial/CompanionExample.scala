package info.hadoop.tutorial

object CompanionExample extends App{
  val emp = new EmployeeS(1001,"Hadoop")
}

class EmployeeS(val id:Int,var dept:String){
  println(s"$id,$dept")
  println("Country=>"+EmployeeS.country)
}

object EmployeeS{
  val country:String="INDIA"
}
package info.hadoop.tutorial

object CompanionObject extends App{
  val p = new Pizza("thin")

  //println(p.toString())
  //println(p.crustType)
 // println(Pizza.getFoo)
}

class Pizza(var crustType:String){
  override def toString()="Crust type is "+crustType
  println("Value of Thin=>"+Pizza.CRUST_TYPE_THIN)
  println("Value of Thick=>"+Pizza.CRUST_TYPE_THICK)
}

object Pizza{
  val CRUST_TYPE_THIN="thin"
  val CRUST_TYPE_THICK="thick"
  def getFoo="Foo"
  println("adsad"+toString())
}
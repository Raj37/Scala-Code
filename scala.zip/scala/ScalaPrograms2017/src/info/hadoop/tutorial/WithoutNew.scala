package info.hadoop.tutorial

object WithoutNew extends App{
  val dinesh= Person1("Dinesh")
  
  dinesh.printMessage()
}

class Person1(val name:String){
  var age:Int=30
  var address:String="NY"
  val ssn:String="XXX333YYY"
  
  def printMessage()={
    println(s"Hello user details are==>$name,$age,$address")
  }
}

object Person1{
  
  def apply(name:String):Person1={
    val p = new Person1(name)
    p
  }
}
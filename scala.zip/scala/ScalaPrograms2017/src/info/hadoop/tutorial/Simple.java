/**
 * 
 */
package info.hadoop.tutorial;

//import info.hadoop.tutorial.Simple.EmployeeJ;

/**
 * @author rajka
 *
 */
class Simple {

	/**
	 * 
	 */
	public Simple() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Simple Java Program");
		EmployeeJ raj = new EmployeeJ("Raj", 26, 5000.50f, "Pune");
		EmployeeJ subu = new EmployeeJ();
		System.out.println("Raj Record=>"+raj.getName()+" "+raj.getAge()+" "+raj.getSalary()+" "+raj.getAddress());
		subu.setName("Subarnayam");
		subu.setAge(35);
		subu.setSalary(7500.75f);
		subu.setAddress("Torronto");
		System.out.println("Subu Record=>"+subu.getName()+" "+subu.getAge()+" "+subu.getSalary()+" "+subu.getAddress());
	}

}
class EmployeeJ{
	/**
	 * @param name
	 * @param age
	 * @param salary
	 * @param address
	 */
	public EmployeeJ(String name, int age, float salary, String address) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
		this.address = address;
	}
	/**
	 * 
	 */
	public EmployeeJ() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String name;
	private int age;
	private float salary;
	private String address;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @return the salary
	 */
	public float getSalary() {
		return salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(float salary) {
		this.salary = salary;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String deriveDeptName(String name){
		return name.toUpperCase();
	}
}
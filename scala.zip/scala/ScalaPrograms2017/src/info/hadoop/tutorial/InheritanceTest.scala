package info.hadoop.tutorial

object InheritanceTest {
  def main(args:Array[String]){
    val p = new Person("Raj","xxx")
    p.printMessage()
    val jothi = new EmployeeI("Jothi","yyy",100)
    println("Age=>"+jothi.age+", Address=>"+jothi.address+", Dept=>"+jothi.dept)
    jothi.printMessage()
  }
}

class Person(val name:String,val pid:String){
  var age:Int=30
  var address:String="NY"
  val ssn:String="55555"
  var country:String="INDIA"
  def printMessage()={
    println(s"Person details=> $name,$pid,$age,$address,$ssn")
  }
  
}

class EmployeeI(override val name:String,override val pid:String,val eid:Int) extends Person(name,pid){
  var dept:String="Bigdata"
  override val ssn:String="666666"
  override def printMessage()={
    super.printMessage()
    println(s"$eid,$dept,$ssn,$country")
    
  }
}

package info.hadoop.tutorial

object Driver extends App{
  val f= new Foo
  println(Foo.double(f))
  
}

class Foo{
  private val secret=2
  
}

object Foo{
  def double(foo:Foo)= foo.secret*2  
}
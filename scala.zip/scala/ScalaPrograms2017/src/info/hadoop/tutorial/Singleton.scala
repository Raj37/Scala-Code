package info.hadoop.tutorial
import java.util.Calendar
import java.text.SimpleDateFormat

object Singleton {
  def main(args: Array[String]) {
    println(DateUtils.gerCuurentTime)
    println(DateUtils.getCurrentDate)

  }
}

object DateUtils {
  def getCurrentDate: String = getCurrentDateTime("EEEE,MMMM d")
  def gerCuurentTime: String = getCurrentDateTime("K:m aa")

  private def getCurrentDateTime(dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime())
  }
}
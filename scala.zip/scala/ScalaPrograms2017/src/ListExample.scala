

object ListExample extends App {

	val numList: Array[Int] = new Array[Int](10)
			numList(0) = 1
			numList(1) = 2
			numList(2) = 3
			numList(3) = 4
			numList(4) = 5
			numList(5) = 6
			numList(6) = 7
			numList(7) = 8
			numList(8) = 9
			numList(9) = 10

			numList.foreach(println)
			val names: Array[String] = new Array[String](5)
			names(0) = "Raj"
			names(1) = "Kamal"
			names(2) = "Piku"
			names(3) = "Piyush"
			names(4) = "Ravi"
			names(5 / 2) = "Subu"
			//names(11/2)="Siva"

			for (name <- names) {
				println(name)
			}
			var a=0
					for(a<-0 to names.length-1){
						println("name=> "+names(a))
					}
}
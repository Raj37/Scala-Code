

object ForLoopExample extends App {
	val nameList: Array[String] = new Array[String](5)
			nameList(0) = "Raj"
			nameList(1) = "Kamal"
			nameList(2) = "Ravi"
			nameList(3) = "Piyush"
			nameList(4) = "Neeraj"
			println("First way of for loop")
			for (name <- nameList) {
				name.replaceAll("R", "A");
				println(name)
			}
println("Second way of for loop")
var i = 0
for (i <- 0 to nameList.length - 1) {

	println(nameList(i))
}
println("for loop with yield first way")

val upperName = for (name <- nameList)yield name.toUpperCase()
upperName.foreach(println)

println("for loop with yield second way")
val upperName1 = for(name<-nameList)yield{
	var s=name.replace("P", "K")
			s.toUpperCase()
			s
}
upperName1.foreach(println)

println("for loop with yield third way")
val upperName2 = for{
	name<-nameList
	s=name.replace("P", "K").toUpperCase()
	//s1=s
}yield s
upperName2.foreach(println)

//for loop with multiple counter

for(i<- 0 to 2;j<-1 to 2)
	println(s"i=$i,j=$j")

	//for loop with list
	var numList:List[Int]= List(1,2,3,4,5)

	var myList:Array[Double]=Array(1.9, 2.9, 3.4, 3.5)
	for(num<-numList){
		println(num)
	}
	for(list<-myList){
		println(list)
	}

	//Sum of list items
	var total=0.0
			for(list<-myList){
				total+=list
			}
	println("Sum=>"+total)

	//Maximum of list item
	var max=myList(0)
	for(i<-1 to myList.length-1){
		if(myList(i)>max)
			max=myList(i)
	}
	println("Max=>"+max)




}
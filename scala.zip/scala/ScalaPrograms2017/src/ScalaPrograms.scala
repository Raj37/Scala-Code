

object ScalaPrograms extends App {
  println("Welcome to scala programming world")
}


import scala.util.control._
object BreakStmt extends App{

	val numList=List(1,2,3,4,5,6,7,8,9)
			//var list=0
			val loop = new Breaks
			loop.breakable{
		for(list<-numList){
			println("List elements=>"+list)
			if(list == 4){
				loop.break
			}
		}
	}
	println("After the for loop")
}
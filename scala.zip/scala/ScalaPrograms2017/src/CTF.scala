
import java.util.Scanner
object CTF extends App{

	val scanner = new java.util.Scanner(System.in)
			println("Enter temperature in Centigrade\n")
			val c = scanner.nextLine()

			val c1=c.toInt

			val f1:Float = 9/5f

			//println("\n f1 =>"+f1)

			val f2= c1*f1

			//println("\n f2 =>"+f2)

			val f= f2+32

			println("\nFahrenheit =>"+f)

}
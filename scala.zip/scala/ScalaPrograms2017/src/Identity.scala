

object Identity extends App{

	def identity(x:Int):Int=x

			def square(x:Int)=x*x

			def cube(x:Int)=x*x*x

			def sumSimple(a:Int,b:Int):Int=if(a==b)a else a + sumSimple(a+1,b)

			def sumSquare(a:Int,b:Int):Int=if(a==b)square(a) else square(a) + sumSquare(a+1,b)

			def sumCube(a:Int,b:Int):Int=if(a==b)cube(a) else cube(a) + sumCube(a+1,b)

			println("sumSimple=>"+sumSimple(1,3))

			println("sumSquare=>"+sumSquare(1,3))

			println("sumCube=>"+sumCube(1,3))

			//Higher order functions

			def sum(f:Int=>Int,a:Int,b:Int):Int={
					if(a==b)f(a) else f(a)+sum(f,a+1,b)
			}
			println("Higher Order Function Output")
			println(sum(identity,1,3))
			println(sum(square,1,3))
			println(sum(cube,1,3))

			//Anonymous functions
			println("Anonymous Function Output")
			println(sum(x=>x,1,3))
			println(sum(x=>x*x,1,3))
			println(sum(x=>x*x*x,1,3))
			
			val addOne=(x:Int)=>x+1
			println("addOne=>"+addOne(10))
			
			def addOne1(x:Int)=x+1
			println("addOne1=>"+addOne1(10))
			
			//Functions with place holder _
			
			val someNum=List(1,2,3,4,5,6,7)
			println("filter result=>"+someNum.filter(_>4))
			
			//Function returns function
			
			def sum2(a:Int):Int=>Int={
			  def fun(b:Int)={b+1}
			  fun
			}
			println("sum2=>"+sum2(10)(20))
			//println(fun(20))
			
			//Lexical Closure
			def fun1():Int=>Int={
			  val y=1
			  
			  def add(x:Int):Int=x+y
			  println("add=>"+add(10))
			  add
			}
			def fun2()={
			  val y=2
			  val f=fun1()
			  println("f(10)=>"+f(10))  
			}
			fun2()
			
			var votingAge=18
			val isOfVotingAge=(age:Int)=>age>=votingAge
			
			println("IsvotingAge=>"+isOfVotingAge(20))
			
			var more =1
			val addMore=(x:Int)=>x+more
			addMore(10)
			println("addMore=>"+addMore(10))
			
			//var thresold=10
			def removeLowScores(a:List[Int],thresold:Int):List[Int]=a.filter(score=>score>thresold)
			println(removeLowScores(List(3,9,7,10,45,90),10))
			
			//Lazy Vals
			
			def hello()={
			  println("Hello")
			  10
			}
			val a=hello()
			lazy val b=hello()
		//	println("lazy value=>"+(b+b))
			
			//Methods on Collections
			val a1=List(1,2,3,4,5,6,7)
			
			val b1=a1.map(x=>x*x)
			println("map=>"+b1)
			
			val c1=a1.filter(x=>x<5)
			println("filter=>"+c1)
			
			val d1=a1.reduce((x,y)=>x+y)
			println("reduce=>"+d1)
			
			def even(x:Int)=(x%2)==0
			
			val a2=List(1,2,3,4,5,6,7)
			val b2=List(2,4,6,5,10,11,13,12)
			
			println(a2.forall(even))
			println(a2.exists(even))
			println(b2.takeWhile(even))
			println(b2.partition(even))
			
			//Pattern matching with Lists
			
			def fun3(a:List[Int])=a match {
			  case List(0,p,q)=>p+q
			  case _ => -1
			}
			println(fun3(List(0,10,20)))
			println(fun3(List(0,1,2,3)))
			println(fun3(List(1,10,20)))
			
}
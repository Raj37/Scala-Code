

object LoopExample extends App {
  var a = 10
  println("Entered into while loop")
  while (a < 20) {

    println("a=> " + a)
    a += 1

  }
  println("Exited from while loop")
  println("Num of times while loop executed=> " + a)
  var b = 20
  println("Entered into do..while loop")
  do {

    println("b=>" + b)
    b += 1
  } while (b < 30)
  println("Exited from do..while loop")
  println("Num of times do..while loop executed=> " + b)
}
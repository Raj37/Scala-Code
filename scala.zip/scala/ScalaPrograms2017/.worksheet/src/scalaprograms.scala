object scalaprograms {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(66); 
  println("Welcome to the Scala worksheet");$skip(13); val res$0 = 
  2 * 5 + 10;System.out.println("""res0: Int = """ + $show(res$0));$skip(54); 

  val nameList: Array[String] = new Array[String](5);System.out.println("""nameList  : Array[String] = """ + $show(nameList ));$skip(22); 
  nameList(0) = "Raj";$skip(24); 
  nameList(1) = "Kamal";$skip(23); 
  nameList(2) = "Ravi";$skip(25); 
  nameList(3) = "Piyush";$skip(25); 
  nameList(4) = "Neeraj";$skip(35); 
  println("First way of for loop");$skip(81); 
  for (name <- nameList) {
    val s = name.replace("R", "A")
    println(s)
  };$skip(76); 
  for (name <- nameList) {
    name.replace("R", "A")
    println(name)
  }}
}

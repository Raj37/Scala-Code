

object ReferentialTransparencyBroken {
	def main(args:Array[String]):Unit = {                                  
			println("")                                                    
			println(" ------------ StringBuffer Append --------------- ")  
			strBufferAppend()                                             
			println("")                                                    
			println(" ======== Referential Transparency (broken) ======= ")
			refTransparencyStrBuffer()                                     
			println("")                                                    
	}                                                                      
	def strBufferAppend() = {                                             
			val x = new StringBuffer("Hello")                              
					val y = x.append(", World")                                    
					val r1 = y.toString                                            
					println(s"StrBuffer appended variable value - r1 : $r1")       
					val r2 = y.toString                                            
					println(s"StrBuffer appended variable value - r2 : $r2")       
	}                                                                      
	def refTransparencyStrBuffer() = {                                     
			val x = new StringBuffer("Hello")                        
					val r1 = x.append(", World").toString                          
					println(s"StrBuffer appended direct value - r1 : $r1") 
	
					val r2 = x.append(", World").toString                          
					println(s"StrBuffer appended direct value - r2 : $r2")         
	}   
}
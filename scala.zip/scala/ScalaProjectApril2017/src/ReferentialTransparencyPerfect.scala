

object ReferentialTransparencyPerfect {
	def main(args:Array[String]):Unit = {
			println("")
			println("----------- String Reverse --------------- ")
			stringReverse()
			println("")
			println(" ======= Referential Transparency ========")
			refTransparencyString()
			println("")
	}
	def stringReverse() = {
			val x = "Hello, World"
					println(s"Input : $x")
					val r1 = x.reverse
					println(s"Reverse - variable value r1 : $r1")
					val r2 = x.reverse
					println(s"Reverse - variable value r2 : $r2")
	}
	def refTransparencyString() = {
			val r1 = "Hello, World".reverse
					println(s"Reverse - direct value r1 : $r1")
					val r2 = "Hello, World".reverse
					println(s"Reverse - direct value r2 : $r2")
	}

}
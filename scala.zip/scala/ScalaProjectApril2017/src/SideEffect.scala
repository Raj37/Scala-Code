

object SideEffect {
	var count = 0;
	def modifyValue(x:Int):Int = {
			count = count + 1
					x + count
	}
	def plusOne(x:Int):Int = {
			x + 1
	}
	def main(args: Array[String]):Unit = {
			val x = 1
					for(i <- 1 to 3) {
						val modified = modifyValue(x)
								println(s"Input : $x, Modified : $modified")
								println("Input : "+x+", Modified : "+modified)
					}
			println("------------")
			for(i <- 1 to 3) {
				val incremented = plusOne(x)
						println(s"Input : $x, Incremented : $incremented")
			}
	}


}
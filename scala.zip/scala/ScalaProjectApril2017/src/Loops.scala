

object Loops {
	def main(args:Array[String]):Unit={
			var i=0
					while(i<args.length){
						println(args(i))
						i=i+1
					}
			println("---------------------------")
			args.foreach(arg1 => println(arg1))
			println("---------------------------")
			args.foreach((f:String) => (println(f)))
			
			println("---------------------------")
			//var x=0
			for(x <- 1 to 10){
			  println(x)
			}
	}
}
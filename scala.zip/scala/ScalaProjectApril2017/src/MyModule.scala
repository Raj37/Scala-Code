import scala.collection.immutable.List


object MyModule {
	def abs(n:Int)={
			if(n<0) -n
			else n
	}
	def formatAbs(x:Int)={
			val msg:String="Jai Hind %d" 
					msg.format(x,abs(x))
	}

	def nameFunction(f:String,l:String)={
	val fname:String=f
	val lname:String=l
	println("My name is "+f+" "+l)
	}
	def fact(n:Int):Int={

			if (n == 0) 
				return 1
			else if(n<0)
			  return 0 
			else
				return n * fact(n-1)
	}
	
	def fact1(n:Int):Int= n match{
	  
	  case 0 =>1
	  case n if n>0 => n*fact1(n-1)
	  case n if n <0 => n
	}
	def maxValue(x:Int,y:Int):Int={
	  if(x>y)x
	  else y
	}
	def main(args:Array[String]):Unit=
		{
	  val max=maxValue(10,20)
	  println("MAX : " +max)
	      nameFunction("raj","kamal")
	      var intList = List(2,4,5,6,7)
	      println("Complete List : "+intList)
        var firstOddNumber =intList.filter(x => x%2==1).head
        println("First odd number in List is : "+firstOddNumber)
	      var lastOddNumber=intList.filter(x=>x%2==1).tail.head
	      println("Last odd number in List is : "+lastOddNumber)
				println("Before first")
				println(abs(-50)) 
				println("first")
				println(abs(-18))
				println("second")
				println(abs(30))
				println("third")
				println(abs(-50))
				println("fourth")
				println(abs(-10))
				println("fivth")

				println("formatAbs is called")
				println(formatAbs(20))
				
				println(fact(0))
				println(fact(5))
				println(fact1(3))
				println(fact1(-10))
				
				val msg = "Goodbye cruel world!"
				val multiLine=
				   "This is the next line."
				println(s"value of multiLine is : $multiLine")
				
				val greetString = new Array[String](5)
				//greetString.update(0,"Hello")
				greetString(0)="Hello"
				greetString(0)="Hello1"
				greetString.update(1,"Raj")
				greetString.update(2,"1")
				greetString.update(3,"Bigdata")
				greetString.update(4,"Hadoop")
				
				for(x <- 0 to 4){
				  println(greetString(x))
				}
				
	  var arr = Array("I","AM","ARRAY")
	  for(x <- 0 to 2)
	    println(arr(x))
	 /* val a=10
	  for(a <- 1 to 5){
	    a=a+1
	    println()
	    }*/
		} 
}
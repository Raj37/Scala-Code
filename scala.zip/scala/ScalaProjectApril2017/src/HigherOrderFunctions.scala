

object HigherOrderFunctions {
	def operation(f:(Int,Int) => Int) {
		println(f(5,5))
	}
	def main(args:Array[String]):Unit = {
			val add = (x:Int, y:Int) => { x + y }
			operation(add)
			val subtract = (x:Int, y:Int) => { x - y }
			operation(subtract)
			val multiply = (x:Int, y:Int) => { x * y }
			operation(multiply)
	}


}
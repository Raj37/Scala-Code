

object SumOfSquaresOfOdd {
  def main(args:Array[String]):Unit={
    val intList=List(1,2,3,4,5)
    val sum=intList.filter(x=>x%2==1).map(x=>x*x).reduce((x_1,x_2)=>(x_1+x_2))
    println("sum of square of odd numbers in List is : "+sum)
  }
}
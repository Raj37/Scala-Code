
object practice {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(62); 
  println("Welcome to the Scala worksheet");$skip(6); val res$0 = 
  2+3;System.out.println("""res0: Int(5) = """ + $show(res$0));$skip(6); val res$1 = 
  2+7;System.out.println("""res1: Int(9) = """ + $show(res$1));$skip(105); 
  //comment
  /*Another*/
  /** Another type of comment*/
  
  def abs(n:Int):Int=
  if(n<0) -n
  else n;System.out.println("""abs: (n: Int)Int""");$skip(61); 
  
  def main(args: Array[String]):Unit=
  println(abs(100));System.out.println("""main: (args: Array[String])Unit""")}
  
}
